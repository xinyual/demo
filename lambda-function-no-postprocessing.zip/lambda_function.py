import json
import requests
import boto3
from requests_aws4auth import AWS4Auth
from urllib.parse import urlparse
import cfnresponse
import time

def lambda_handler(event, context):
    print("Event:", event)
    request_type = event['RequestType']

    if request_type in ['Update', 'Delete']:
        return respond_to_cloudformation(event, context, cfnresponse.SUCCESS, {})

    resource_properties = event['ResourceProperties']
    host = resource_properties['AOSEndpoint']
    model_endpoint = get_sagemaker_endpoint(event, context)
    aos_role_arn = resource_properties['AOSRoleArn']
    current_region = context.invoked_function_arn.split(':')[3]
    
    print("Model endpoint:", model_endpoint)
    awsauth = create_aws_auth(context, host)
    
    if not host.endswith('/'):
        host += '/'
    connector_url = host + '_plugins/_ml/connectors/_create'
    
    connector_payload = create_connector_payload(model_endpoint, aos_role_arn, current_region)
    print("Payload for creating connector:", connector_payload)
    print("URL for creating connector:", connector_url)
    
    connector_response = requests.post(connector_url, auth=awsauth, json=connector_payload, headers={"Content-Type": "application/json"})
    print("Response for creating connector:", connector_response)
    
    if connector_response.status_code != 200:
        print("Status code not 200 for creating connector")
        return respond_to_cloudformation(event, context, cfnresponse.FAILED, {}, "Status code not 200 for creating connector")

    connector_id = connector_response.json()["connector_id"]
    model_id = register_model(connector_id, host, awsauth)
    
    if not model_id:
        print("Failed to register model")
        return respond_to_cloudformation(event, context, cfnresponse.FAILED, {}, "Failed to register model")

    response_data = {
        "model_endpoint": model_endpoint,
        "connector_id": connector_id,
        "model_id": model_id
    }

    return respond_to_cloudformation(event, context, cfnresponse.SUCCESS, response_data)

def create_aws_auth(context, host):
    region = context.invoked_function_arn.split(':')[3]
    service = 'es'
    session = boto3.Session()
    credentials = session.get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    return awsauth

def create_connector_payload(model_endpoint, aos_role_arn, region):
    return {
        "name": "Sagemaker Connector: embedding",
        "description": "The connector to sagemaker embedding model",
        "version": 1,
        "protocol": "aws_sigv4",
        "credential": {"roleArn": aos_role_arn},
        "parameters": {"region": region, "service_name": "sagemaker"},
        "actions": [create_connector_action(model_endpoint)]
    }

def get_sagemaker_endpoint(event, context):
    resource_properties = event['ResourceProperties']
    sagemaker_region = context.invoked_function_arn.split(':')[3]
    sagemaker_endpoint = 'https://runtime.sagemaker.' + sagemaker_region + '.amazonaws.com/endpoints/' + resource_properties['SMEndpointName'] + '/invocations'
    return sagemaker_endpoint

def connector_pre_process_function():
    return """
    StringBuilder builder = new StringBuilder();
    builder.append("\\\"");
    builder.append(params.text_docs[0]);
    builder.append("\\\"");
    def parameters = "{" +"\\\"inputs\\":" + builder + "}";
    return "{" +"\\\"parameters\\":" + parameters + "}";
    """

def connector_post_process_function():
    return """
    def name = "sentence_embedding";
    def dataType = "FLOAT32";
    if (params.result == null || params.result.length == 0) {
        return null;
    }
    def shape = [params.result[0].length];
    def json = "{" +
               "\\\"name\\\":\\\"" + name + "\\\"," +
               "\\\"data_type\\\":\\\"" + dataType + "\\\"," +
               "\\\"shape\\":" + shape + "," +
               "\\\"data\\":" + params.result[0] +
               "}";
    return json;
    """

def create_connector_action(model_endpoint):
    return {
            "action_type": "predict",
            "method": "POST",
            "headers": {"content-type": "application/json"},
            "url": model_endpoint,
            "request_body": "[\"${parameters.inputs}\"]",
            "pre_process_function": connector_pre_process_function()
        }

def register_model(connector_id, host, awsauth):
    url = host + '_plugins/_ml/models/_register?deploy=true'
    payload = {
        "name": f"sagemaker-model-for-connector-{connector_id}",
        "function_name": "remote",
        "description": f"Sagemaker Model for connector {connector_id}",
        "connector_id": connector_id,
    }
    response = requests.post(url, auth=awsauth, json=payload, headers={"Content-Type": "application/json"})
    print("Response for registering model:", response)

    if response.status_code == 200:
        task_id = response.json().get("task_id")
        print("Model registered, task ID:", task_id)
        time.sleep(1)  # Waiting for 1 second
        return get_model_from_task(task_id, host, awsauth)

    return ""

def get_model_from_task(task_id, host, awsauth):
    url = host + "_plugins/_ml/tasks/" + task_id
    response = requests.get(url, auth=awsauth, headers={"Content-Type": "application/json"})
    print("Response for getting model from task:", response)

    if response.status_code == 200:
        return response.json().get("model_id")

    return ""

def respond_to_cloudformation(event, context, response_status, response_data, reason=None):
    response_data['model_endpoint'] = response_data.get('model_endpoint', "")
    response_data['connector_id'] = response_data.get('connector_id', "")
    response_data['model_id'] = response_data.get('model_id', "")
    cfnresponse.send(event, context, response_status, response_data, context.log_stream_name, reason)
    return {"statusCode": 200 if response_status == cfnresponse.SUCCESS else 500, "body": json.dumps(response_data)}
