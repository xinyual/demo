import json

from ts.torch_handler.base_handler import BaseHandler
import torch
import os
import time
from transformers import PreTrainedTokenizerFast
from sagemaker_inference import logging
from ts.handler_utils.micro_batching import MicroBatching


class SparseEncodingModelHandler(BaseHandler):
    def __init__(self):
        super().__init__()
        mb_handle = MicroBatching(self)
        self.handle = mb_handle
        self.tokenizer = None

    def initialize(self, context):
        self.manifest = context.manifest

        parallelism = context.model_yaml_config.get("micro_batching", {}).get(
            "parallelism", None
        )
        if parallelism:
            self.handle.parallelism = parallelism

        micro_batch_size = context.model_yaml_config.get("micro_batching", {}).get(
            "micro_batch_size", 1
        )
        self.handle.micro_batch_size = micro_batch_size
        print(micro_batch_size, parallelism, "micro batch size")
        #print("here are the manifest")
        #print(context)
        print("here are the manifest", self.manifest)
        #print("here are the manifest")
        properties = context.system_properties
        model_dir = properties.get("model_dir")
        self.device = torch.device("cuda:" + str(properties.get("gpu_id")) if torch.cuda.is_available() else "cpu")
        print("device:", self.device)
        # Read model serialize/pt file
        serialized_file = self.manifest['model']['serializedFile']
        #print(serialized_file)
        tokenizer_path = os.path.join(model_dir, "tokenizer.json")
        model_pt_path = os.path.join(model_dir, serialized_file)
        self.tokenizer = PreTrainedTokenizerFast(tokenizer_file=tokenizer_path)
        #self.model = torch.jit.load(model_pt_path, map_location=self.device)
        self.idf = json.load(open(os.path.join(model_dir, "idf.json")))

    def preprocess(self, requests):
        t1 = time.time()
        inputSentence = []
        #logger = logging.get_logger()
        #logger.info("for each preprocess" + str(len(requests)))
        print("for each preprocess" + str(len(requests)))
        #logger.info(requests)
        batch_idx = []
        for request in requests:

            request_body = request.get("body")
            if isinstance(request_body, bytearray):
                request_body = request_body.decode('utf-8')
                request_body = json.loads((request_body))
            #logger.info(request_body)
            if isinstance(request_body, list):
                inputSentence += request_body
                batch_idx.append(len(request_body))
            else:
                inputSentence.append(request_body)
                batch_idx.append(1)
        input_data = self.tokenizer(inputSentence, return_tensors="pt", padding=True)
        #logger.info(inputSentence)
        input_data = input_data.to(self.device)
        t2 = time.time()
        print("pre process: " + str(t2 - t1))
        return {"input": input_data, "batch_l":batch_idx}

    def inference(self, data, *args, **kwargs):
        batch_idx = data["batch_l"]
        data = data["input"].input_ids

        return {"pred": data, "batch_l": batch_idx}

    def postprocess(self, prediction):
        t1 = time.time()
        batch_idx = prediction["batch_l"]
        prediction = prediction["pred"]
        batch = len(prediction)
        output = []
        tensor = prediction
        for i in range(batch):
            tokenWeights = {}
            for token_idx in tensor[i]:
                token = self.tokenizer.decode(token_idx, skip_special_tokens=True)
                if len(token) > 0:
                    tokenWeights[token] = self.idf[token]
            output.append(tokenWeights)
        outputs = []
        index = 0
        #print("batch info", len(output), batch_idx)
        for b in batch_idx:
            #print("index:", index, b, len(output[index:index + b]))
            outputs.append(output[index:index + b])
            index += b
        #print(batch_idx)
        t2 = time.time()
        print("post process: " + str(t2 - t1))
        return outputs

    def handle(self, data, context):
        model_input = self.preprocess(data)
        model_output = self.inference(model_input)
        return self.postprocess(model_output)
